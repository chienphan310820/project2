export { BadgeModule } from './badge.module';
export { MDBBadgeComponent } from './mdb-badge.component';
