import { Rule } from '@angular-devkit/schematics';
export declare function ngAdd(options: any): Rule;
