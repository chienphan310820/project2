import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smoothscroll',
  templateUrl: './smoothscroll.component.html',
  styleUrls: ['./smoothscroll.component.scss']
})
export class SmoothscrollComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
